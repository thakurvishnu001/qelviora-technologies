import './config.mjs';
import readline from 'node:readline/promises';
import {randomUUID,randomBytes,scrypt as scryptCallback} from 'node:crypto';
import {promisify} from 'node:util';
import {one,run,transaction} from './database.mjs';
const scrypt=promisify(scryptCallback);
const io=readline.createInterface({input:process.stdin,output:process.stdout});
function hiddenPassword(prompt){
 if(!process.stdin.isTTY)throw Error('Open Admin Account Setup.cmd in an interactive terminal.');
 io.close();process.stdout.write(prompt);process.stdin.setRawMode(true);process.stdin.resume();
 return new Promise((resolve,reject)=>{let value='';function finish(){process.stdin.off('data',receive);process.stdin.setRawMode(false);process.stdout.write('\n');process.stdin.pause()}
 function receive(chunk){for(const c of String(chunk)){if(c==='\u0003'){finish();reject(Error('Setup cancelled.'));return}if(c==='\r'||c==='\n'){finish();resolve(value);return}if(c==='\u007f'||c==='\b'){value=value.slice(0,-1);continue}if(c.charCodeAt(0)>=32)value+=c}}process.stdin.on('data',receive)});
}
try{
 console.log('Qelviora administrator account setup\nPasswords are entered here and are never displayed.');
 const previous=(await io.question('Current admin email (leave blank for a new account): ')).trim().toLowerCase();
 const email=(await io.question('New admin login email [qelvioratechnologies@gmail.com]: ')).trim().toLowerCase()||'qelvioratechnologies@gmail.com';
 if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))throw Error('Enter a valid email address.');
 const existing=previous?one("SELECT * FROM users WHERE email=? AND role='ADMIN'",previous):one('SELECT * FROM users WHERE email=?',email);
 if(previous&&!existing)throw Error('The current administrator account was not found.');
 const collision=one('SELECT id FROM users WHERE email=?',email);if(collision&&existing&&collision.id!==existing.id)throw Error('That email belongs to another account.');
 const name=(await io.question('Administrator name [Qelviora Administrator]: ')).trim()||existing?.name||'Qelviora Administrator';
 const password=await hiddenPassword('New password (12–128 characters): ');
 if(password.length<12||password.length>128)throw Error('Use a password of 12–128 characters. No account was changed.');
 const confirmation=await hiddenPassword('Confirm new password: ');if(password!==confirmation)throw Error('Passwords do not match. No account was changed.');
 const salt=randomBytes(16).toString('hex'),encoded=salt+':'+Buffer.from(await scrypt(password,salt,64)).toString('hex');
 transaction(()=>{const id=existing?.id||randomUUID();if(existing)run("UPDATE users SET email=?,name=?,password_hash=?,role='ADMIN',status='ACTIVE' WHERE id=?",email,name,encoded,id);else run("INSERT INTO users(id,name,email,phone,password_hash,role,created_at,status) VALUES(?,?,?,?,?,'ADMIN',?,'ACTIVE')",id,name,email,'',encoded,new Date().toISOString());run('DELETE FROM sessions WHERE user_id=?',id);run('UPDATE resets SET used=1 WHERE user_id=?',id);run('INSERT INTO audit VALUES(?,?,?,?,?)',randomUUID(),id,'LOCAL_ADMIN_ACCOUNT_SETUP',id,new Date().toISOString())});
 console.log('Administrator account updated. Sign in at account.html, then open admin.html.');
}catch(error){console.error(error.message);process.exitCode=1}finally{io.close()}
