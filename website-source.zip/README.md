# Qelviora Technologies — Learn | Build | Grow

This edition merges the supplied Vypax website content and application features into Qelviora. Hackathon pages, partner registration, submissions and event payment entry points are disabled.

## Open the website

Install Node.js 22.15 or newer, extract the complete ZIP and double-click Launch Website.cmd. It opens http://127.0.0.1:4177. Accounts, learning, assessments, payments and administration require the included Node server; opening HTML files directly will not run these features. Libraries are bundled with their licenses.

## Included

- 107 skill guides with ten chapters, guest progress, server-scored assessments and account-owned completion certificates.
- 33 internship paths with monthly notes, projects and 20-question assessments. Duration options: 1 month ₹499, 2 months ₹999, 3 months ₹1,299, 6 months ₹1,999.
- Accounts, dashboard, admin content editor, enquiries, payment proof review, private materials, newsletter and email setup.
- Qelviora homepage, existing company content, Projects, Career Center, reviews, Founder Md. Aajam and Co-founder Vishnu Chauhan.
- Certificates branded Qelviora Technologies and signed using the supplied Vishnu Chauhan signature image, Co-founder. Demo certificates carry a DEMO watermark. The signature image was provided by the website owner for this certificate.
- Free Personal Development program benefit for paid internship and training participants.

Communication Skills retains ₹7,999 total: ₹7,000 training + ₹999 registration. Other fees, batch dates and meeting links require configuration. Most training batches were marked Coming soon in the supplied source.

## Administrator

Create your account, then run node make-admin.mjs your-account-email@example.com from this folder. Sign in and open admin.html. There are no default administrator credentials.

## Email and payments

Staff enquiries route to qelvioratechnologies@gmail.com. Submissions save to the database first; notifications queue until SMTP is configured in Administration or through private EMAIL_SERVER and EMAIL_FROM settings. Password resets and learner notifications go to the account owner. Actual email delivery has not been tested.

The retained UPI ID is 7060711685@kotakbank, recipient MD AAJAM. Administrators can update payment settings. Materials unlock after administrator approval of payment; entering a reference does not verify payment. Optional Razorpay requires private RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET. No real payment was made during validation.

## Hosting and persistence

Run one Node/SQLite server behind HTTPS with persistent storage. Set HOST, PORT and APP_URL for your hosting environment. The default database is .data/qelviora.sqlite; QELVIORA_DATABASE_PATH can select another private persistent file. Back up the database, uploads and email settings. Never publish .env, .data or private uploads.

The optional dist/server/index.js Worker serves public assets and proxies API calls to a configured HTTPS API_ORIGIN. A static-only host cannot run accounts, learning progress or admin features. No hosted deployment was performed in this update.

## Validation

Local checks covered public pages, blocked event routes, registration, guest progress transfer, server scoring, certificate ownership and branding, admin restrictions, payment-gated materials, monthly assessments and enquiry persistence. Fixture data was kept outside this download, with email disabled.



## Learning and administrator update
All 107 skill guides now contain ten structured chapters with worked cases, exercises, common mistakes and self-check questions. Core assessment principles are preserved and made explicit.
Open Admin Account Setup.cmd to create an administrator or change an existing admin email and password locally. Password entry is hidden; the script stores a salted scrypt hash and revokes previous sessions. No default password has been added.
Registration QR and UPI details supplied for Aajam Ali are visible on Contact and the registration pages. The bank scanner identifies the recipient as MD AAJAM.
