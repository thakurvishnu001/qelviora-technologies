# Deploy the full website

Forms, accounts and Administration require this Node server. Deploy the repository root as a Node web service, not dist as a static site. Use Node 22.15+, start command npm start, HOST=0.0.0.0 and NODE_ENV=production. Set APP_URL to the exact public HTTPS origin, without a path. A localhost APP_URL rejects live form submissions.

Render: upload this repository to your Git provider, create a Web Service, and use the supplied render.yaml or the settings above. The Blueprint selects a paid Starter service with a persistent disk; review the hosting cost before creating it. Set APP_URL after you know the assigned domain. Set QELVIORA_DATABASE_PATH to /var/data/qelviora.sqlite with a persistent disk mounted at /var/data. A free service without persistent storage may lose accounts and submissions when restarted.

The downloaded ZIP excludes the local account database. To create your deployed admin account, open the hosting service shell and run npm run admin:setup. Enter the email and password privately. Updating the localhost administrator does not update the deployed database.

For enquiry emails, configure EMAIL_SERVER with your SMTP connection URL and EMAIL_FROM with the sender email, using private hosting environment variables or Administration email settings. Your normal website login password is not an SMTP password. Without SMTP, submissions are saved and email notifications remain queued.

Verify /healthz returns status ok and /api/auth/me returns JSON. If an API URL returns a web page or 404, the backend is not being served. Test sign-in and a form submission after deployment. Keep the browser and API on the same origin; the optional static Worker requires a separate HTTPS API_ORIGIN backend.

Back up persistent files and the database. Uploaded files and saved email configuration currently use .data alongside the application; mount or back up this directory too if you use these features.
