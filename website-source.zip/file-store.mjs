import {mkdir,writeFile,readFile} from 'node:fs/promises';
import {resolve,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {db,all,run} from './database.mjs';
const remote=!!process.env.TURSO_DATABASE_URL;
const folder=resolve(process.env.UPLOAD_DIRECTORY||fileURLToPath(new URL('./.data/uploads',import.meta.url)));
if(remote)db.exec('CREATE TABLE IF NOT EXISTS file_chunks(id TEXT NOT NULL,part INTEGER NOT NULL,data TEXT NOT NULL,PRIMARY KEY(id,part))');
export async function saveFile(id,bytes){
 if(!/^[a-f0-9-]{36}$/.test(id))throw Error('Invalid file identifier.');
 if(remote){try{for(let offset=0,part=0;offset<bytes.length;offset+=128*1024,part++)run('INSERT INTO file_chunks VALUES(?,?,?)',id,part,bytes.subarray(offset,offset+128*1024).toString('base64'));}catch(error){run('DELETE FROM file_chunks WHERE id=?',id);throw error;}}
 else{await mkdir(folder,{recursive:true});await writeFile(join(folder,id),bytes,{flag:'wx'});}
}
export async function loadFile(id){
 if(!/^[a-f0-9-]{36}$/.test(id))throw Error('Invalid file identifier.');
 if(!remote)return readFile(join(folder,id));
 const rows=all('SELECT data FROM file_chunks WHERE id=? ORDER BY part',id);if(!rows.length)throw Error('Document not found.');return Buffer.concat(rows.map(row=>Buffer.from(row.data,'base64')));
}
