import {parentPort} from 'node:worker_threads';
const base=new URL(process.env.TURSO_DATABASE_URL.replace(/^libsql:/,'https:'));
if(base.protocol!=='https:')throw Error('Turso requires HTTPS.');
let baton=null,inTransaction=false;
const encode=value=>value==null?{type:'null'}:typeof value==='number'?{type:Number.isInteger(value)?'integer':'float',value:Number.isInteger(value)?String(value):value}:typeof value==='bigint'?{type:'integer',value:String(value)}:{type:'text',value:String(value)};
const decode=value=>value.type==='null'?null:value.type==='integer'||value.type==='float'?Number(value.value):value.type==='blob'?value.base64:value.value;
function statements(sql){
 const result=[];let part='',quote='';
 for(let i=0;i<sql.length;i++){const c=sql[i];if(quote){part+=c;if(c===quote){if(sql[i+1]===quote)part+=sql[++i];else quote='';}}else if(c==='\''||c==='"'){quote=c;part+=c;}else if(c===';'){if(part.trim())result.push(part.trim());part='';}else part+=c;}
 if(part.trim())result.push(part.trim());return result.filter(x=>!/^PRAGMA\s+(journal_mode|busy_timeout)/i.test(x));
}
async function query(sqls,args=[]){
 const start=sqls.length===1&&/^BEGIN\b/i.test(sqls[0]),end=sqls.length===1&&/^(COMMIT|ROLLBACK)\b/i.test(sqls[0]);
 const keep=start||inTransaction&&!end;
 const requests=sqls.map(sql=>({type:'execute',stmt:{sql,args:args.map(encode)}}));
 if(!keep)requests.push({type:'close'});
 const response=await fetch(new URL('/v2/pipeline',base),{method:'POST',headers:{'Authorization':'Bearer '+process.env.TURSO_AUTH_TOKEN,'Content-Type':'application/json'},body:JSON.stringify({baton,requests}),signal:AbortSignal.timeout(30000)});
 if(!response.ok)throw Error('Database connection failed (HTTP '+response.status+').');
 const value=await response.json();baton=value.baton||null;
 const failed=value.results?.find(item=>item.type==='error');
 if(failed){if(!baton)inTransaction=false;throw Object.assign(Error(failed.error?.message||'Database query failed.'),{code:failed.error?.code});}
 if(start)inTransaction=true;if(end)inTransaction=false;
 const result=value.results?.findLast(item=>item.response?.type==='execute')?.response.result||{};
 return {rows:(result.rows||[]).map(row=>Object.fromEntries((result.cols||[]).map((col,i)=>[col.name,decode(row[i])]))),changes:result.affected_row_count||0,lastInsertRowid:result.last_insert_rowid==null?null:Number(result.last_insert_rowid)};
}
let chain=Promise.resolve();
parentPort.on('message',message=>{chain=chain.then(async()=>{
 const state=new Int32Array(message.shared,0,2);let result;
 try{result={value:await query(message.operation==='exec'?statements(message.sql):[message.sql],message.args)}}catch(error){result={error:error.message,code:error.code||'DATABASE_ERROR'}}
 let bytes=Buffer.from(JSON.stringify(result));if(bytes.length>message.shared.byteLength-8)bytes=Buffer.from(JSON.stringify({error:'Database result is too large.'}));
 new Uint8Array(message.shared,8,bytes.length).set(bytes);Atomics.store(state,1,bytes.length);Atomics.store(state,0,1);Atomics.notify(state,0);
 });});
