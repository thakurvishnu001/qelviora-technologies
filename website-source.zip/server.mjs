import {registrationPayment} from './registration-payments.mjs';
import {handlePaymentQr} from './payment-qr.mjs';
import './config.mjs';
import {bootstrapAdmin} from './admin-bootstrap.mjs';
import {handleMaterials} from './materials.mjs';
import {renderCatalogHtml,catalogPageResponse} from './catalog-pages.mjs';
import {createHash} from 'node:crypto';
import {handlePublicForm} from './public-forms.mjs';
import {handleUploads} from './uploads.mjs';
import {learningIdentity,learningStore} from './guest-learning.mjs';
import http from "node:http";
import { handlePortal,currentUser,refreshInternships } from "./portal-api.mjs";
import { one,run } from "./database.mjs";
import { startMail } from "./mail.mjs";
import { readFile, writeFile, mkdir, rename } from "node:fs/promises";
import { createLearningHandler } from "./learning-api.mjs";
import { fileURLToPath } from "node:url";
import { handleAssistant } from "./assistant-api.mjs";
const learningBank=JSON.parse(await readFile(new URL('./learning-bank.json',import.meta.url),'utf8'));
const handleLearning=createLearningHandler(learningBank,learningStore);
if(process.env.NODE_ENV==='production'){
 if(!process.env.APP_URL)throw Error('Set APP_URL to your public HTTPS website URL.');
 const publicUrl=new URL(process.env.APP_URL);if(publicUrl.protocol!=='https:')throw Error('Production APP_URL must use HTTPS.');
 process.env.APP_URL=publicUrl.origin;
}
bootstrapAdmin();
startMail();
refreshInternships();
setInterval(()=>{try{refreshInternships()}catch(error){console.error('Certificate refresh failed:',error.message)}},60000).unref();
const root=new URL("./dist/",import.meta.url),port=Number(process.env.PORT||4174);
const files=new Set(["about.html","account-nav.js","account.html","account.js","admin-form-editor.js","admin-queries.js","admin-tools.js","admin.html","admin.js","announcements.js","app.js","assistant.js","career-application.html","career-application.js","career-center.html","career-guide-aptitude.html","career-guide-career-roadmaps.html","career-guide-communication.html","career-guide-interviews.html","career-guide-linkedin.html","career-guide-mock-interviews.html","career-guide-portfolio.html","career-guide-power-bi.html","career-guide-python-practice.html","career-guide-resume.html","career-guide-sql-practice.html","career-path.html","career-path.js","careers.html","catalog-detail.html","catalog-public.js","certificate-demo.html","certificate-sample.svg","communication-registration.html","communication-registration.js","communication-upi.png","contact.html","database-forms.js","enquiry-popup.js","enquiry-routing.js","enquiry-schema.js","favicon.svg","index.html","internship-ai-ml.html","internship-application.html","internship-application.js","internship-business-analytics.html","internship-catalog.js","internship-cybersecurity.html","internship-data-analytics.html","internship-digital-marketing.html","internship-payment-qr.jpg","internship-ui-ux.html","internship-web-development.html","internships.html","learning-data.js","learning.js","lesson.html","logo.jpg","logo.svg","motion.js","paid-internship.js","portal.html","portal.js","practice-form.html","practice-form.js","program-artificial-intelligence.html","program-backend-development.html","program-business-analyst.html","program-communication-skills.html","program-data-analyst.html","program-data-science.html","program-frontend-development.html","program-full-stack-development.html","program-generative-ai.html","program-human-resource.html","program-machine-learning.html","programs.html","project-ai-resume-screening.html","project-customer-segmentation.html","project-e-commerce-analytics.html","project-loan-eligibility.html","project-retail-sales-intelligence.html","projects.html","quizzes-data.js","quizzes.js","reference-theme.css","services.html","skill.html","skills.html","student-reviews.js","styles.css","subscribe.js","training.html","vishnu-chauhan-signature.png"]);
const assetCache=new Map();
http.createServer(async(req,res)=>{try{const origin="http://"+req.headers.host,url=new URL(req.url,origin);if(url.pathname==='/healthz'){res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});return res.end(JSON.stringify({status:'ok'}))}if(/hackathon|event-apply/.test(url.pathname)||url.searchParams.get("type")==="hackathons"){res.writeHead(404);return res.end("Not available")}if(url.pathname.startsWith("/api/")){const chunks=[];let size=0;for await(const chunk of req){size+=chunk.length;if(size>(["/api/admin/payment-qr","/api/forms/submit","/api/portal/hackathon-upload","/api/payments/receipt-upload"].includes(url.pathname)?5300000:url.pathname==="/api/admin/materials/upload"?53000000:url.pathname==="/api/admin/catalog"?250000:20000)){res.writeHead(413,{"Content-Type":"application/json"});return res.end(JSON.stringify({error:"Upload must be under 5 MB."}))}chunks.push(chunk)}const body=Buffer.concat(chunks);if(req.headers["content-type"]?.includes("application/json")){let submitted;try{submitted=JSON.parse(body.toString())}catch{}if(submitted?.type==="hackathons"||submitted?.category==="Hackathon"){res.writeHead(404);return res.end("Not available")}}const headers=new Headers(req.headers);headers.set("x-client-ip",req.socket.remoteAddress||"local");const request=new Request(url,{method:req.method,headers,...(req.method==="POST"?{body}:{})});let result;
if(['/api/registration-payment','/api/admin/registration-payments'].includes(url.pathname))result=registrationPayment(request,currentUser(request),req.method==='POST'?JSON.parse(body.toString()):{});
else if(url.pathname==='/api/admin/payment-qr'||url.pathname.startsWith('/api/payment-qr/'))result=await handlePaymentQr(request,currentUser(request));
else if(url.pathname==='/api/admin/materials/upload')result=await handleMaterials(request,currentUser(request));
else if(url.pathname==='/api/catalog/page')result=catalogPageResponse(request);
else if(url.pathname==='/api/forms/submit')result=await handlePublicForm(request);
else if(['/api/portal/hackathon-upload','/api/payments/receipt-upload'].includes(url.pathname)||url.pathname.startsWith('/api/uploads/'))result=await handleUploads(request,currentUser(request));
else if(url.pathname.startsWith('/api/learning/')){
 const user=currentUser(request),identity=learningIdentity(request,user);
 request.headers.set('x-learning-user',identity.id);request.headers.set('x-learning-guest',String(identity.guest));
 if(identity.guest&&url.pathname.endsWith('/certificate'))result=Response.json({error:'Sign in to download your certificate.'},{status:401});
 else result=await handleLearning(request);
 if(identity.cookie)result.headers.append('Set-Cookie',identity.cookie);
}else if(url.pathname.startsWith('/api/assistant'))result=await handleAssistant(request,process.env);
else result=await handlePortal(request);if(result&&!result.headers.has('Cache-Control'))result.headers.set('Cache-Control','no-store');res.writeHead(result?.status||404,Object.fromEntries(result?.headers||[]));return res.end(result?Buffer.from(await result.arrayBuffer()):"Not found")}
const name=url.pathname==="/"?"index.html":url.pathname.slice(1);if(!files.has(name)){res.writeHead(404);return res.end("Not found")}let cached=process.env.NODE_ENV==='production'?assetCache.get(name):null;if(!cached){const bytes=await readFile(new URL(name,root));cached={bytes,etag:'\"'+createHash('sha256').update(bytes).digest('hex')+'\"'};if(process.env.NODE_ENV==='production')assetCache.set(name,cached)}if(name.endsWith('.html')){const original=cached.bytes.toString('utf8'),rendered=renderCatalogHtml(original,url);if(rendered!==original){const output=rendered.replace('<html','<html data-catalog-rendered="true"');res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-cache','X-Content-Type-Options':'nosniff'});return res.end(output)}}const {bytes,etag}=cached;const ext=name.split(".").at(-1);if(req.headers['if-none-match']===etag){res.writeHead(304,{ETag:etag,'Cache-Control':'public, max-age=0, must-revalidate'});return res.end()}res.writeHead(200,{"Content-Type":({html:"text/html; charset=utf-8",js:"text/javascript",css:"text/css",jpg:"image/jpeg",png:"image/png",svg:"image/svg+xml",json:"application/json; charset=utf-8"})[ext],"X-Content-Type-Options":"nosniff","ETag":etag,"Cache-Control":ext==="html"?"public, max-age=0, must-revalidate":"public, max-age=300"});res.end(bytes)}catch(error){console.error('Request failed:',error.code||error.name||'Error');if(req.url?.startsWith('/api/')){res.writeHead(500,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(JSON.stringify({error:'The website server could not process this request. Please try again later.'}));}else{res.writeHead(500);res.end('Server error')}}}).listen(port,process.env.HOST||"0.0.0.0",()=>console.log("http://127.0.0.1:"+port));

