import {randomUUID} from 'node:crypto';
import {one,run,transaction} from './database.mjs';
export function bootstrapAdmin(){
 const email=(process.env.ADMIN_BOOTSTRAP_EMAIL||'').trim().toLowerCase(),encoded=process.env.ADMIN_BOOTSTRAP_PASSWORD_HASH;
 if(!email&&!encoded)return;
 if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||encoded&&!/^([a-f0-9]{32}):([a-f0-9]{128})$/.test(encoded))throw Error('Invalid private admin bootstrap settings.');
 const existing=one('SELECT id,role FROM users WHERE email=?',email);
 if(existing){if(existing.role!=='ADMIN')throw Error('The bootstrap email already belongs to a learner. Resolve this in administration.');return;}
 const id=randomUUID();transaction(()=>{run("INSERT INTO users(id,name,email,phone,password_hash,role,created_at,status) VALUES(?,?,?,?,?,'ADMIN',?,'ACTIVE')",id,'Qelviora Administrator',email,'',encoded||'RESET_REQUIRED',new Date().toISOString());run('INSERT INTO audit VALUES(?,?,?,?,?)',randomUUID(),id,'INITIAL_ADMIN_SETUP',id,new Date().toISOString())});
}
