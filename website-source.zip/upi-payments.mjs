import {liveLibrary as library,handleCatalog,catalogItem} from './catalog-service.mjs';
import {randomUUID} from 'node:crypto';
import {readFileSync} from 'node:fs';
import {createRequire} from 'node:module';
import {one,run,record,records,setting,transaction} from './database.mjs';
import {queueMail} from './mail.mjs';
const require=createRequire(import.meta.url),QR=require('./vendor/qrcode/lib/core/qrcode.js'),SVG=require('./vendor/qrcode/lib/renderer/svg-tag.js');

const json=(data,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store'}});
export function verifiedEvent(userId,event){return records(userId,'event-enrollment').some(row=>row.data.event===event&&row.data.status==='VERIFIED')}
export function eventFee(event){const text=library.hackathons[event]?.fee||'';const match=text.match(/₹([\d,]+)/);return match?Number(match[1].replaceAll(',','')):null}
export async function handlePayments(request,user,body){
 const url=new URL(request.url),path=url.pathname;if(!path.startsWith('/api/payments/')&&path!=='/api/admin/payment-settings')return null;
 if(!user)return json({error:'Sign in to apply and view your payment.'},401);
 if(path==='/api/admin/payment-settings'&&request.method==='POST'){
  if(user.role!=='ADMIN')return json({error:'Administrator access required.'},403);
  const upi=typeof body.upi==='string'?body.upi.trim():'',recipient=typeof body.recipient==='string'?body.recipient.trim():'';
  if(!/^[a-zA-Z0-9._-]{2,128}@[a-zA-Z0-9.-]{2,64}$/.test(upi)||recipient.length<2||recipient.length>100||/[<>\x00-\x1f]/.test(recipient))return json({error:'Enter the official UPI ID and recipient name.'},400);
  const scope=body.scope||'all';if(!['all','internships','hackathons'].includes(scope))return json({error:'Payment use must be all, internships or hackathons.'},400);for(const key of scope==='all'?['upi-payment','internship-upi-payment']:[scope==='internships'?'internship-upi-payment':'upi-payment'])run('INSERT INTO settings VALUES(?,?) ON CONFLICT(key) DO UPDATE SET data=excluded.data',key,JSON.stringify({upi,recipient}));run('INSERT INTO audit VALUES(?,?,?,?,?)',randomUUID(),user.id,'UPDATE_UPI','upi-payment',new Date().toISOString());return json({ok:true});
 }
 if(path==='/api/payments/training-apply'&&request.method==='POST'){const course=library.courses[body.course];if(!course)return json({error:'Choose a valid training program.'},404);if(course.paymentEnabled!==true)return json({error:'Payments have not been enabled for this training program.'},403);const text=String(course.price||course.fee||''),match=text.match(/(?:₹|INR|Rs\.?)\s*([\d,]+)(?:\.([0-9]{1,2}))?/i);if(!match)return json({error:'Training fees have not been published. Contact Qelviora before paying.'},409);const fee=Number(match[1].replaceAll(',','')+(match[2]?'.'+match[2]:''));if(!Number.isFinite(fee)||fee<=0)return json({error:'This program does not require a UPI payment.'},409);const previous=records(user.id,'training-enrollment').find(row=>row.data.course===body.course);if(previous)return json({id:previous.id,status:previous.data.status});const id=randomUUID();record(id,'training-enrollment',user.id,{course:body.course,fee,status:'AWAITING_PAYMENT',name:user.name,email:user.email});return json({id,status:'AWAITING_PAYMENT'},201);}
 if(path==='/api/payments/event-apply'&&request.method==='POST'){
  const event=body.event;if(!Object.hasOwn(library.hackathons,event||''))return json({error:'Choose a valid hackathon.'},404);
  if(library.hackathons[event].status==='Coming soon')return json({error:'Applications for this event are coming soon.'},409);
  const existing=records(user.id,'event-enrollment').find(r=>r.data.event===event);if(existing)return json({id:existing.id,status:existing.data.status});
  const fee=eventFee(event);if(fee===null)return json({error:'The event fee has not been published.'},409);
  const id=randomUUID(),status=fee===0?'VERIFIED':'AWAITING_PAYMENT';record(id,'event-enrollment',user.id,{event,fee,status,name:user.name,email:user.email});return json({id,status},201);
 }
 const id=body.id||url.searchParams.get('id'),row=one("SELECT * FROM records WHERE id=? AND user_id=? AND kind IN ('internship','event-enrollment','training-enrollment')",id||'',user.id);if(!row)return json({error:'Application not found.'},404);const data=JSON.parse(row.data);
 const target=row.kind==='training-enrollment'?'portal.html?type=courses&id='+encodeURIComponent(data.course):row.kind==='internship'?'portal.html?internship='+encodeURIComponent(row.id):'portal.html?type=hackathons&id='+encodeURIComponent(data.event);
 if(path==='/api/payments/panel'&&request.method==='GET'){
  if(row.kind==='training-enrollment'&&library.courses[data.course]?.paymentEnabled!==true)return json({error:'Payments are currently disabled for this training program.'},403);
  const configuration=row.kind==='training-enrollment'?(setting('training-upi-payment')||setting('internship-upi-payment')):row.kind==='internship'?(setting('internship-upi-payment')||{upi:'harshsaini05012004@okaxis',recipient:'Harsh Saini'}):setting('upi-payment');const title=row.kind==='training-enrollment'?(library.courses[data.course]||catalogItem('courses',data.course)).name:row.kind==='internship'?(library.internships[data.domain]||catalogItem('internships',data.domain)).name:(library.hackathons[data.event]||catalogItem('hackathons',data.event)).name;
  let upiUrl=null,qr=null;if(configuration&&data.fee>0&&['AWAITING_PAYMENT','REJECTED','PENDING'].includes(data.status)){
   const params=new URLSearchParams({pa:configuration.upi,pn:configuration.recipient,am:String(data.fee),cu:'INR',tn:'Qelviora '+row.id,tr:row.id});upiUrl='upi://pay?'+params;qr=SVG.render(QR.create(upiUrl,{errorCorrectionLevel:'M'}),{width:256,margin:4});
  }
  return json({id:row.id,kind:row.kind,title,fee:data.fee,status:data.status,feedback:data.feedback||'',upi:configuration?.upi||null,recipient:configuration?.recipient||null,upiUrl,qr,qrImage:configuration?.qrImage||null,target});
 }
 if(path==='/api/payments/proof'&&request.method==='POST'){
  if(!['AWAITING_PAYMENT','REJECTED'].includes(data.status))return json({error:'This payment is already submitted or verified.'},409);
  const reference=typeof body.reference==='string'?body.reference.trim():'';if(reference.length<5||reference.length>120)return json({error:'Enter a valid UPI transaction reference.'},400);
  let receipt='';if(body.receipt){try{const parsed=new URL(body.receipt);if(parsed.protocol!=='https:')throw Error();receipt=parsed.href}catch{return json({error:'Receipt links must use HTTPS.'},400)}}
  if(body.receiptUploadId){const upload=one("SELECT * FROM records WHERE id=? AND user_id=? AND kind='upload'",body.receiptUploadId,user.id);if(!upload||JSON.parse(upload.data).applicationId!==row.id)return json({error:'Upload a receipt for this application.'},400);receipt=new URL('/api/uploads/'+upload.id,process.env.APP_URL||url.origin).href;data.receiptUploadId=upload.id;}
  if(!receipt)return json({error:'Upload your payment receipt along with the transaction ID.'},400);
  data.status='PENDING';data.reference=reference;data.receipt=receipt;const origin=process.env.APP_URL||url.origin;
  transaction(()=>{run('UPDATE records SET data=? WHERE id=?',JSON.stringify(data),row.id);queueMail('qelvioratechnologies@gmail.com','Verify '+(row.kind==='training-enrollment'?'training':row.kind==='internship'?'internship':'hackathon')+' payment',`Student: ${user.name}\nEmail: ${user.email}\nApplication: ${row.id}\nAmount: INR ${data.fee}\nUPI reference: ${reference}\nReceipt: ${receipt||'Not provided'}\nYES — ${origin}/admin.html?review=${row.id}&decision=VERIFIED\nNO — ${origin}/admin.html?review=${row.id}&decision=REJECTED\nCheck the actual received payment before confirming. Opening an email link does not approve a payment.`)});
  return json({message:'Payment reference saved. Qelviora will verify the received payment before opening your workspace.'});
 }
 return json({error:'Not found.'},404);
}
