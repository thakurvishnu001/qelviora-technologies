import {randomUUID,randomBytes,createHash} from 'node:crypto';
import {db,one,all,run,transaction} from './database.mjs';
import {queueMail} from './mail.mjs';
const hash=value=>createHash('sha256').update(value).digest('hex');
const topics=['Training','Careers','Internships'];
db.exec(`CREATE TABLE IF NOT EXISTS subscribers(id TEXT PRIMARY KEY,email TEXT UNIQUE NOT NULL,topics TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 0,confirm_hash TEXT NOT NULL,unsubscribe_token TEXT NOT NULL,expires INTEGER NOT NULL,created_at TEXT NOT NULL);CREATE INDEX IF NOT EXISTS subscribers_active ON subscribers(active);CREATE TABLE IF NOT EXISTS published_updates(id TEXT PRIMARY KEY,topic TEXT NOT NULL,title TEXT NOT NULL,message TEXT NOT NULL,url TEXT NOT NULL,created_at TEXT NOT NULL);`);
export async function handleNewsletter(request,user,body){
 const path=new URL(request.url).pathname,json=(data,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store'}});
 if(path==='/api/subscriptions'&&request.method==='POST'){
  const email=typeof body.email==='string'?body.email.trim().toLowerCase():'',chosen=Array.isArray(body.topics)?[...new Set(body.topics)].filter(t=>topics.includes(t)):[];
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||email.length>254||!chosen.length||body.consent!==true)return json({error:'Enter your email, choose updates and agree to subscribe.'},400);
  const key='subscribe:'+request.headers.get('x-client-ip'),now=Date.now();run('DELETE FROM limits WHERE expires<?',now);if((one('SELECT count FROM limits WHERE key=?',key)?.count||0)>=5)return json({error:'Please wait 15 minutes before trying again.'},429);run('INSERT INTO limits VALUES(?,1,?) ON CONFLICT(key) DO UPDATE SET count=count+1',key,now+900000);
  const existing=one('SELECT * FROM subscribers WHERE email=?',email),token=randomBytes(32).toString('hex'),id=existing?.id||randomUUID(),unsubscribe=existing?.unsubscribe_token||randomBytes(32).toString('hex'),origin=process.env.APP_URL||new URL(request.url).origin;
  transaction(()=>{if(existing)run('UPDATE subscribers SET confirm_hash=?,expires=? WHERE id=?',hash(token),now+86400000,id);else run('INSERT INTO subscribers VALUES(?,?,?,?,?,?,?,?)',id,email,JSON.stringify(chosen),0,hash(token),unsubscribe,now+86400000,new Date().toISOString());recordPreference(id,chosen);queueMail(email,'Confirm your Qelviora updates subscription','Confirm updates for '+chosen.join(', ')+': '+origin+'/index.html?confirmSubscription='+token+'\nThis link expires in 24 hours. Ignore this email if you did not request it.');});return json({message:'Your request is saved. Confirm the email sent to your inbox to activate updates. Delivery waits for the sending account to be connected.'},201);
 }
 if(path==='/api/subscriptions/confirm'&&request.method==='POST'){
  if(typeof body.token!=='string'||!/^[a-f0-9]{64}$/.test(body.token))return json({error:'Invalid confirmation link.'},400);const row=one('SELECT * FROM subscribers WHERE confirm_hash=? AND expires>?',hash(body.token),Date.now());if(!row)return json({error:'This link has expired or was already used. Subscribe again.'},400);run("UPDATE subscribers SET active=1,confirm_hash='',expires=0,topics=(SELECT topics FROM subscription_preferences WHERE id=subscribers.id) WHERE id=?",row.id);return json({message:'Subscription confirmed. You will receive the updates you selected.'});
 }
 if(path==='/api/subscriptions/unsubscribe'&&request.method==='POST'){
  if(typeof body.token!=='string'||!/^[a-f0-9]{64}$/.test(body.token))return json({error:'Invalid unsubscribe link.'},400);run("UPDATE subscribers SET active=0,confirm_hash='',expires=0 WHERE unsubscribe_token=?",body.token);return json({message:'You are unsubscribed from Qelviora updates.'});
 }
 if(path==='/api/admin/updates'&&request.method==='POST'){
  if(user?.role!=='ADMIN')return json({error:'Administrator access required.'},403);const {topic}=body,title=typeof body.title==='string'?body.title.trim():'',message=typeof body.message==='string'?body.message.trim():'';if(!topics.includes(topic)||title.length<3||title.length>150||message.length<10||message.length>5000)return json({error:'Choose a category and enter a title and update.'},400);let link;try{link=new URL(body.url,process.env.APP_URL||request.url);if(!['http:','https:'].includes(link.protocol))throw Error()}catch{return json({error:'Use a valid website link.'},400)}
  const id=randomUUID(),origin=process.env.APP_URL||new URL(request.url).origin;let count=0;transaction(()=>{run('INSERT INTO published_updates VALUES(?,?,?,?,?,?)',id,topic,title,message,link.href,new Date().toISOString());for(const subscriber of all('SELECT * FROM subscribers WHERE active=1'))if(JSON.parse(subscriber.topics).includes(topic)){queueMail(subscriber.email,'Qelviora '+topic+': '+title,message+'\nMore information: '+link.href+'\nUnsubscribe: '+origin+'/index.html?unsubscribe='+subscriber.unsubscribe_token);count++;}});return json({message:'Update published. '+count+' confirmed subscribers have a notification queued.'},201);
 }
 return null;
}
function recordPreference(id,topics){run('CREATE TABLE IF NOT EXISTS subscription_preferences(id TEXT PRIMARY KEY,topics TEXT NOT NULL)');run('INSERT INTO subscription_preferences VALUES(?,?) ON CONFLICT(id) DO UPDATE SET topics=excluded.topics',id,JSON.stringify(topics));}
