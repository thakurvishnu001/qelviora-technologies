import {Worker} from 'node:worker_threads';

// Keep the existing synchronous database interface while HTTPS runs in a worker.
export class RemoteDatabase {
 constructor(){
  if(!process.env.TURSO_DATABASE_URL||!process.env.TURSO_AUTH_TOKEN)throw Error('Configure both Turso database settings.');
  this.worker=new Worker(new URL('./remote-database-worker.mjs',import.meta.url));
  this.worker.unref();
 }
 call(operation,sql,args=[]){
  const shared=new SharedArrayBuffer(12*1024*1024),state=new Int32Array(shared,0,2);
  this.worker.postMessage({shared,operation,sql,args});
  if(Atomics.wait(state,0,0,35000)==='timed-out')throw Error('Database request timed out.');
  const result=JSON.parse(Buffer.from(shared,8,state[1]).toString());
  if(result.error)throw Object.assign(Error(result.error),{code:result.code});
  return result.value;
 }
 exec(sql){return this.call('exec',sql)}
 prepare(sql){return {all:(...args)=>this.call('query',sql,args).rows,get:(...args)=>this.call('query',sql,args).rows[0],run:(...args)=>{const value=this.call('query',sql,args);return {changes:value.changes,lastInsertRowid:value.lastInsertRowid}}}}
 close(){this.worker.terminate()}
}
