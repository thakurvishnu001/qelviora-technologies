import {certificateSvg} from './certificate-template.mjs';
// Shared server-side learning rules. Answer keys never enter public lesson assets.
export function createLearningHandler(bank, store) {
  const sessions = new Map();
  const json = (value, status = 200, extra = {}) => Response.json(value, { status, headers: { 'Cache-Control': 'no-store', ...extra } });
  const validName = value => typeof value === 'string' && value.trim().length >= 2 && value.trim().length <= 80 && !/[<>\x00-\x1f]/.test(value);
  const escape = value => String(value).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]));
  return async function handleLearning(request) {
    const url = new URL(request.url);
    if (!url.pathname.startsWith('/api/learning/')) return null;
    if (!['GET', 'POST'].includes(request.method)) return json({error:'Method not allowed.'},405);
    if (request.method === 'POST' && request.headers.get('origin') !== new URL(process.env.APP_URL||request.url).origin) return json({error:'Please submit from this website.'},403);
    const sid=request.headers.get('x-learning-user');
    const headers={};const guest=request.headers.get('x-learning-guest')==='true';
    if(!sid)return json({error:'Please sign in to continue.'},401);
    const previous = sessions.get(sid) || Promise.resolve();
    let release;
    const lock = new Promise(resolve => release = resolve); sessions.set(sid, lock); await previous;
    try {
      let body = {};
      if (request.method === 'POST') {
        if (!request.headers.get('content-type')?.includes('application/json')) return json({error:'Use a JSON request.'},415);
        const raw = await request.text(); if (raw.length>12000) return json({error:'Request is too large.'},413);
        try { body = JSON.parse(raw); } catch { return json({error:'Check the submitted information.'},400); }
        if (!body || typeof body!=='object' || Array.isArray(body)) return json({error:'Invalid request.'},400);
      }
      const data = await store.get(sid) || {skills:{},certificates:{}};
      // Refresh earned credentials against the current catalog, preserving their IDs.
      let refreshed=false;
      for(const [earnedSlug,earned] of Object.entries(data.skills)){
        const current=bank[earnedSlug];if(!current||!earned.certificate)continue;
        const cert=earned.certificate;
        if(cert.skillName!==current.name||cert.skillSlug!==earnedSlug){cert.skillName=current.name;cert.skillSlug=earnedSlug;refreshed=true;}
        data.certificates[cert.id]=cert;
      }
      if(refreshed)await store.put(sid,data);
      const action = url.pathname.split('/').pop();
      if (action === 'certificate' && request.method === 'GET') {
        const id=url.searchParams.get('id');const cert=Object.hasOwn(data.certificates,id||'')?data.certificates[id]:null;
        if (!cert) return json({error:'Certificate not found in this learning session.'},404,headers);
        return new Response(certificateSvg(cert),{headers:{...headers,'Content-Type':'image/svg+xml; charset=utf-8','Cache-Control':'private, no-store','Content-Security-Policy':"default-src 'none'; style-src 'unsafe-inline'",'X-Content-Type-Options':'nosniff'}});
      }
      const slug = body.skill || url.searchParams.get('skill');
      if (typeof slug!=='string' || !Object.hasOwn(bank,slug)) return json({error:'Choose a valid skill.'},404,headers);
      const skill = bank[slug];
      const progress = data.skills[slug] || {completed:[],attempts:[],certificate:null};
      if (action==='state' && request.method==='GET') return json({completed:progress.completed,notes:progress.notes||{},chapterCount:skill.chapters,attempts:progress.attempts.map(({score,total,passed,date})=>({score,total,passed,date})),certificate:guest?null:progress.certificate,certificateReady:!!progress.certificate,guest},200,headers);
      if(action==='notes' && request.method==='POST'){
        if(!Number.isInteger(body.chapter)||body.chapter<1||body.chapter>skill.chapters||typeof body.notes!=='string'||body.notes.length>5000)return json({error:'Invalid chapter or notes (maximum 5,000 characters).'},400);
        progress.notes||={};progress.notes[body.chapter]=body.notes;data.skills[slug]=progress;await store.put(sid,data);return json({saved:true});
      }
      if (action==='complete' && request.method==='POST') {
        if (!Number.isInteger(body.chapter) || body.chapter<1 || body.chapter>skill.chapters) return json({error:'Choose a valid chapter.'},400);
        if (body.chapter>1 && !progress.completed.includes(body.chapter-1)) return json({error:'Complete the previous chapter first.'},409);
        if (!progress.completed.includes(body.chapter)) progress.completed.push(body.chapter);
      } else if (action==='assessment' && request.method==='GET') {
        if (progress.completed.length<skill.chapters) return json({error:'Complete all 10 chapters to unlock the assessment.'},403,headers);
        return json({questions:skill.questions.map(({correct,...question})=>question),passPercentage:skill.passPercentage},200,headers);
      } else if (action==='assess' && request.method==='POST') {
        if (progress.completed.length<skill.chapters) return json({error:'Complete every chapter before the assessment.'},403);
        if (!validName(body.name)) return json({error:'Enter your name using 2–80 characters.'},400);
        if (!Array.isArray(body.answers)||body.answers.length!==skill.questions.length||body.answers.some((a,i)=>!Number.isInteger(a)||a<0||a>=skill.questions[i].options.length)) return json({error:'Answer every question before submitting.'},400);
        const last = progress.attempts.at(-1);
        if (last && Date.now()-Date.parse(last.date)<30000) return json({error:'Please wait 30 seconds before another attempt.'},429);
        const score=skill.questions.reduce((sum,q,i)=>sum+(body.answers[i]===q.correct?1:0),0),total=skill.questions.length;
        const passed=score/total*100>=skill.passPercentage;
        progress.attempts.push({score,total,passed,date:new Date().toISOString()});
        // Bound session size while retaining the most recent attempts.
        progress.attempts=progress.attempts.slice(-100);
        if (passed && !progress.certificate) {
          const id='QELVIORA-'+crypto.randomUUID().toUpperCase();
          const cert={id,name:body.name.trim(),skillName:skill.name,skillSlug:slug,score,total,date:new Date().toLocaleDateString('en-IN',{timeZone:'Asia/Kolkata'})};
          data.certificates[id]=cert;progress.certificate=cert;
        }
        data.skills[slug]=progress;await store.put(sid,data);
        return json({score,total,passed,certificate:guest?null:progress.certificate,certificateReady:!!progress.certificate,guest},200,headers);
      } else return json({error:'Endpoint not found.'},404,headers);
      data.skills[slug]=progress;await store.put(sid,data);
      return json({completed:progress.completed},200,headers);
    } catch(error) { console.error('Learning request failed:',error.message); return json({error:'Learning progress could not be saved. Please try again.'},503,headers); }
    finally { release(); if (sessions.get(sid)===lock) sessions.delete(sid); }
  };
}
