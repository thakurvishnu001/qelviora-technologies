import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
const path=process.env.QELVIORA_DATABASE_PATH || fileURLToPath(new URL('./.data/qelviora.sqlite',import.meta.url));
mkdirSync(dirname(path),{recursive:true});
export const db=new DatabaseSync(path);
db.exec(`PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;
CREATE TABLE IF NOT EXISTS users(id TEXT PRIMARY KEY,name TEXT NOT NULL,email TEXT NOT NULL UNIQUE,phone TEXT NOT NULL,password_hash TEXT NOT NULL,role TEXT NOT NULL DEFAULT 'STUDENT',created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sessions(token_hash TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id),expires INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS resets(token_hash TEXT PRIMARY KEY,user_id TEXT NOT NULL REFERENCES users(id),expires INTEGER NOT NULL,used INTEGER NOT NULL DEFAULT 0);
CREATE TABLE IF NOT EXISTS records(id TEXT PRIMARY KEY,kind TEXT NOT NULL,user_id TEXT REFERENCES users(id),data TEXT NOT NULL,created_at TEXT NOT NULL);
CREATE INDEX IF NOT EXISTS records_owner ON records(user_id,kind);
CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,data TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS outbox(id TEXT PRIMARY KEY,recipient TEXT NOT NULL,subject TEXT NOT NULL,body TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'PENDING',attempts INTEGER NOT NULL DEFAULT 0,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS limits(key TEXT PRIMARY KEY,count INTEGER NOT NULL,expires INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS audit(id TEXT PRIMARY KEY,user_id TEXT,action TEXT NOT NULL,target TEXT,created_at TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS learning_progress(user_id TEXT PRIMARY KEY REFERENCES users(id),data TEXT NOT NULL);
`);
if(!db.prepare('PRAGMA table_info(users)').all().some(column=>column.name==='status'))db.exec("ALTER TABLE users ADD COLUMN status TEXT NOT NULL DEFAULT 'ACTIVE'");
export const one=(sql,...args)=>db.prepare(sql).get(...args);
export const all=(sql,...args)=>db.prepare(sql).all(...args);
export const run=(sql,...args)=>db.prepare(sql).run(...args);
export function transaction(fn){db.exec('BEGIN IMMEDIATE');try{const value=fn();db.exec('COMMIT');return value}catch(error){db.exec('ROLLBACK');throw error}}
export const setting=key=>{const row=one('SELECT data FROM settings WHERE key=?',key);return row?JSON.parse(row.data):null};
export const record=(id,kind,user,data)=>run('INSERT INTO records VALUES(?,?,?,?,?)',id,kind,user,JSON.stringify(data),new Date().toISOString());
export const records=(user,kind)=>all('SELECT * FROM records WHERE user_id=? AND kind=? ORDER BY created_at',user,kind).map(r=>({...r,data:JSON.parse(r.data)}));

// Keep the previously supplied Qelviora payment destination; administrators can update it.
const initialPayment={upi:"7060711685@kotakbank",recipient:"MD AAJAM",methodId:"qelviora-primary"};
for(const key of ["internship-upi-payment","training-upi-payment"])run("INSERT OR IGNORE INTO settings VALUES(?,?)",key,JSON.stringify(initialPayment));
run("INSERT OR IGNORE INTO settings VALUES(?,?)","payment-methods",JSON.stringify([{id:"qelviora-primary",name:"Qelviora registration",upi:initialPayment.upi,recipient:initialPayment.recipient,scope:"training-internships"}]));
