# Hosting and the 20,000-user target

Recommended target: Cloudflare static hosting/CDN for public pages, Render horizontally scaled Node services behind the same-origin API proxy, managed PostgreSQL with connection pooling, private S3-compatible object storage for uploads, and a separate email/background-job worker. Keep APIs and private attachments out of shared caches. Configure authenticated SMTP and a reachable APP_URL before email delivery.

Current status: this release is a single-server SQLite application. It is NOT certified for 20,000 concurrent users. Public assets now support ETags, cache headers and production in-memory caching; a health endpoint is available at /healthz. Payment polling uses 30 seconds instead of 10. These improvements do not establish capacity.

Before horizontal scaling, migrate database.mjs and all synchronous SQLite queries/transactions to an asynchronous PostgreSQL repository, move private uploads to object storage, and use shared locking/idempotency for assessment completion, certificates and payment reviews. Only one worker may claim each queued mail/job. Existing local SQLite database and uploads require a tested migration and backups. Do not attach one local writable disk to a multi-instance service.

Capacity acceptance: exercise 20,000 active sessions using realistic dwell times and proportions of public browsing, learning saves, assessment submissions and uploads. Run only against authorised staging infrastructure. Establish API latency and error-rate targets, confirm no lost writes or duplicate certificates, test payment/notification idempotency, and measure database connections, CPU, memory and queue age. Increase service replicas and database resources based on these measurements; no provider plan alone guarantees this concurrency.

Provider references:
- https://developers.cloudflare.com/cache/get-started/
- https://render.com/docs/scaling
- https://render.com/docs/disks
