import {canAccessMaterial} from './materials.mjs';
import {mkdir,writeFile,readFile} from 'node:fs/promises';
import {randomUUID} from 'node:crypto';
import {resolve,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {one,record} from './database.mjs';
import {verifiedEvent} from './upi-payments.mjs';
const folder=resolve(process.env.UPLOAD_DIRECTORY||fileURLToPath(new URL('./.data/uploads',import.meta.url)));
export async function handleUploads(request,user){
 const url=new URL(request.url),json=(error,status)=>Response.json({error},{status});
 if(!user)return json('Sign in to upload or download documents.',401);
 if(request.method==='GET'){
  const id=url.pathname.split('/').at(-1),row=one("SELECT * FROM records WHERE id=? AND kind='upload'",id);
  if(!row||row.user_id!==user.id&&user.role!=='ADMIN'&&!canAccessMaterial(user,JSON.parse(row.data)))return json('Document not found.',404);
  const data=JSON.parse(row.data);const bytes=await readFile(join(folder,row.id));
  const headers={'Content-Type':data.kind==='video'?data.mime:'application/octet-stream','X-Content-Type-Options':'nosniff','Cache-Control':'private, no-store'};if(data.kind==='video'){headers['Accept-Ranges']='bytes';const range=request.headers.get('range');if(range){const match=range.match(/^bytes=(\d+)-(\d*)$/);if(!match)return new Response(null,{status:416,headers:{'Content-Range':'bytes */'+bytes.length}});const start=Number(match[1]),end=match[2]?Math.min(Number(match[2]),bytes.length-1):bytes.length-1;if(start>end||start>=bytes.length)return new Response(null,{status:416});return new Response(bytes.subarray(start,end+1),{status:206,headers:{...headers,'Content-Range':`bytes ${start}-${end}/${bytes.length}`,'Content-Length':String(end-start+1)}})}}
  return new Response(bytes,{headers:{...headers,'Content-Type':data.kind==='video'?data.mime:'application/octet-stream','Content-Disposition':`${data.kind==='video'?'inline':'attachment'}; filename*=UTF-8''${encodeURIComponent(data.filename)}`,'X-Content-Type-Options':'nosniff','Cache-Control':'private, no-store'}});
 }
 if(request.method!=='POST')return json('Method not allowed.',405);
 if(request.headers.get('origin')!==new URL(process.env.APP_URL||request.url).origin)return json('Submit from the Qelviora website.',403);
 const receiptUpload=url.pathname==='/api/payments/receipt-upload';let application;
 if(receiptUpload){application=one("SELECT * FROM records WHERE id=? AND user_id=? AND kind IN ('internship','event-enrollment','training-enrollment')",url.searchParams.get('id')||'',user.id);if(!application)return json('Application not found.',404);if(!['AWAITING_PAYMENT','REJECTED'].includes(JSON.parse(application.data).status))return json('This payment is already submitted or verified.',409);}
 if(!receiptUpload&&!verifiedEvent(user.id,'hackathon-2026'))return json('Payment approval is required before submissions.',403);
 const now=Date.now();if(!receiptUpload&&(now<Date.parse('2026-11-12T00:00:00+05:30')||now>=Date.parse('2026-11-14T00:00:00+05:30')))return json('Round 1 uploads open 12–13 November 2026.',403);
 if(one("SELECT COUNT(*) AS n FROM records WHERE user_id=? AND kind='upload'",user.id).n>=20)return json('Upload limit reached. Contact Qelviora for help.',429);
 let form;try{form=await request.formData()}catch{return json('Choose a document to upload.',400)}
 const file=form.get('file');if(!file||typeof file.arrayBuffer!=='function'||!file.size||file.size>5*1024*1024)return json('Choose a document up to 5 MB.',400);
 const ext=file.name.split('.').at(-1).toLowerCase(),bytes=Buffer.from(await file.arrayBuffer());
 const ole=bytes.subarray(0,8).equals(Buffer.from('d0cf11e0a1b11ae1','hex')),zip=bytes.subarray(0,4).equals(Buffer.from('504b0304','hex'));
 const imageValid=(ext==='png'&&bytes.subarray(0,8).equals(Buffer.from('89504e470d0a1a0a','hex')))||(['jpg','jpeg'].includes(ext)&&bytes.subarray(0,3).equals(Buffer.from('ffd8ff','hex')))||(ext==='webp'&&bytes.subarray(0,4).toString()==='RIFF'&&bytes.subarray(8,12).toString()==='WEBP');
 const valid=receiptUpload?imageValid:ext==='pdf'?bytes.subarray(0,5).toString()==='%PDF-':['doc','ppt'].includes(ext)?ole:ext==='docx'?zip&&bytes.includes(Buffer.from('word/document.xml')):ext==='pptx'?zip&&bytes.includes(Buffer.from('ppt/presentation.xml')):false;
 if(!valid)return json(receiptUpload?'Upload a valid PNG, JPG or WEBP receipt image.':'Upload a valid PDF, DOC, DOCX, PPT or PPTX document.',400);
 const id=randomUUID(),filename=file.name.replace(/[^a-zA-Z0-9 ._()-]/g,'_').slice(-120);
 await mkdir(folder,{recursive:true});await writeFile(join(folder,id),bytes,{flag:'wx'});record(id,'upload',user.id,{filename,size:bytes.length,...(receiptUpload?{purpose:'receipt',applicationId:application.id}:{event:'hackathon-2026'})});
 return Response.json({uploadId:id},{status:201});
}
