import './config.mjs';
import { one,run } from './database.mjs';
const email=process.argv[2]?.trim().toLowerCase();
if(!email){console.error('Usage: node make-admin.mjs your-admin-email');process.exit(1)}
const user=one('SELECT id FROM users WHERE email=?',email);
if(!user){console.error('Create the account through the website first.');process.exit(1)}
run("UPDATE users SET role='ADMIN' WHERE id=?",user.id);console.log('Administrator role granted to the specified account.');
