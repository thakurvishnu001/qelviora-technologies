import nodemailer from './vendor/nodemailer/dist/esm/nodemailer.js';
import { randomUUID } from 'node:crypto';
import { all,run } from './database.mjs';
export function queueMail(to,subject,text){run('INSERT INTO outbox(id,recipient,subject,body,created_at) VALUES(?,?,?,?,?)',randomUUID(),to,subject,text,new Date().toISOString())}
let running=false;
export async function deliverMail(){
 if(running||!process.env.EMAIL_SERVER||!process.env.EMAIL_FROM)return;
 running=true;
 try{
  const transport=nodemailer.createTransport(process.env.EMAIL_SERVER);
  for(const message of all("SELECT * FROM outbox WHERE status='PENDING' AND attempts<10 ORDER BY created_at LIMIT 20")){
   try{await transport.sendMail({from:process.env.EMAIL_FROM,to:message.recipient,subject:message.subject,text:message.body,html:/Verify.*payment/i.test(message.subject)?paymentHtml(message.body):undefined});run("UPDATE outbox SET status='SENT',attempts=attempts+1 WHERE id=?",message.id)}
   catch{run('UPDATE outbox SET attempts=attempts+1 WHERE id=?',message.id)}
  }
 }finally{running=false}
}
export function startMail(){setInterval(deliverMail,60000).unref();deliverMail()}


function paymentHtml(text){const esc=value=>value.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));const links=text.match(/https?:\/\/[^\s]+admin\.html\?review=[^\s]+/g)||[];return '<h2>Verify internship payment</h2><pre>'+esc(text)+'</pre>'+links.map((url,i)=>'<a style="display:inline-block;padding:12px 24px;margin:8px;background:'+(i?'#a62c2c':'#225d39')+';color:white;border-radius:8px" href="'+esc(i?url.replace(/&decision=[^&]+/,''):url)+'">'+(i?'Skip / review later':'Verify Payment')+'</a>').join('')+'<p>Sign in as an administrator and confirm your decision.</p>';}
