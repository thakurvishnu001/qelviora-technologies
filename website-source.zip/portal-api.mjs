import {handlePaymentMethods} from './payment-methods.mjs';
import {handleAccounts} from './admin-accounts.mjs';
import {handleFormSchema} from './form-schema.mjs';
import {handleEnquiries} from './admin-enquiries.mjs';
import {handleMaterials} from './materials.mjs';
import {liveLibrary as library,handleCatalog,catalogItem,catalogLibrary} from './catalog-service.mjs';
import {handleNewsletter} from './newsletter.mjs';
import {configureEmail} from './email-setup.mjs';
import {handlePayments,verifiedEvent,eventFee} from './upi-payments.mjs';
import {createOrder,verifyPayment,paymentEnabled} from './payment-service.mjs';
import {certificateSvg as renderCertificate} from './certificate-template.mjs';
import { randomBytes,randomUUID,scrypt as scryptCallback,timingSafeEqual,createHash } from 'node:crypto';
import { promisify } from 'node:util';
import { readFileSync } from 'node:fs';
import { one,all,run,transaction,record,records,setting } from './database.mjs';
import { queueMail,deliverMail,emailConfigured } from './mail.mjs';
const scrypt=promisify(scryptCallback),hash=value=>createHash('sha256').update(value).digest('hex');

const monthlyBank=JSON.parse(readFileSync(new URL('./internship-assessments.json',import.meta.url),'utf8'));
const json=(body,status=200,headers={})=>Response.json(body,{status,headers:{'Cache-Control':'no-store',...headers}});
const clean=(value,max=5000)=>typeof value==='string'?value.trim().slice(0,max):'';
const email=value=>/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)&&value.length<=254;
const link=value=>{try{const u=new URL(value);return u.protocol==='https:'?u.href:null}catch{return null}};
function limit(key,max=10){const now=Date.now();run('DELETE FROM limits WHERE expires<?',now);const row=one('SELECT * FROM limits WHERE key=?',key);if(row&&row.count>=max)throw Object.assign(Error('Too many requests. Please try again in 15 minutes.'),{status:429});run('INSERT INTO limits VALUES(?,1,?) ON CONFLICT(key) DO UPDATE SET count=count+1',key,now+900000)}
export function currentUser(request){const token=request.headers.get('cookie')?.match(/(?:^|;\s*)qelviora_session=([a-f0-9]{64})(?:;|$)/)?.[1];return token?one('SELECT u.id,u.name,u.email,u.phone,u.role FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires>? AND u.status=\'ACTIVE\'',hash(token),Date.now()):null}
async function passwordHash(password){const salt=randomBytes(16).toString('hex');return salt+':'+Buffer.from(await scrypt(password,salt,64)).toString('hex')}
async function passwordMatches(password,encoded){if(!/^[a-f0-9]{32}:[a-f0-9]{128}$/.test(encoded||'')&&encoded==='RESET_REQUIRED')return false;const [salt,key]=encoded.split(':');const value=Buffer.from(await scrypt(password,salt,64));return timingSafeEqual(value,Buffer.from(key,'hex'))}
function session(user,request){const token=randomBytes(32).toString('hex');run('INSERT INTO sessions VALUES(?,?,?)',hash(token),user.id,Date.now()+7*86400000);return {'Set-Cookie':`qelviora_session=${token}; HttpOnly; SameSite=Lax; Path=/; Max-Age=604800${new URL(process.env.APP_URL||request.url).protocol==='https:'?'; Secure':''}`}}
function audit(user,action,target){run('INSERT INTO audit VALUES(?,?,?,?,?)',randomUUID(),user?.id||null,action,target,new Date().toISOString())}
export function addMonths(date,count){const d=new Date(date),day=d.getUTCDate();d.setUTCDate(1);d.setUTCMonth(d.getUTCMonth()+count);const last=new Date(Date.UTC(d.getUTCFullYear(),d.getUTCMonth()+1,0)).getUTCDate();d.setUTCDate(Math.min(day,last));return d.toISOString()}
function internshipView(row,user){const value=row.data,domain=library.internships[value.domain]||catalogItem('internships',value.domain);const active=value.status==='VERIFIED';const count=active?Array.from({length:value.months},(_,i)=>i).filter(i=>Date.parse(addMonths(value.startedAt,i))<=Date.now()).length:0;const projects=active?domain.projects.slice(0,count).map((p,i)=>({...p,month:i+1,release:addMonths(value.startedAt,i)})):[];let certificate=value.certificate||null;
 if(active&&Date.now()>=Date.parse(addMonths(value.startedAt,value.months))&&!certificate){certificate={id:'QELVIORA-INT-'+randomUUID().toUpperCase(),name:user.name,program:domain.name,duration:value.months,date:new Date().toLocaleDateString('en-IN',{timeZone:'Asia/Kolkata'})};value.certificate=certificate;run('UPDATE records SET data=? WHERE id=?',JSON.stringify(value),row.id);queueMail(user.email,'Your Qelviora internship duration certificate is ready','Your selected internship duration has ended. Sign in to your dashboard to download your certificate. This records duration, not a project evaluation.');}
 return {id:row.id,...value,assessments:active?Array.from({length:value.months},(_,i)=>({month:i+1,opensAt:addMonths(value.startedAt,i+1),unlocked:Date.now()>=Date.parse(addMonths(value.startedAt,i+1)),attempts:(value.assessmentAttempts||[]).filter(a=>a.month===i+1)})):[],materials:active?(domain.materials||[]).filter(file=>file.month<=count):[],projects,notes:active?domain.notes.slice(0,count):[],resources:active?domain.resources:[],certificate,endsAt:active?addMonths(value.startedAt,value.months):null};}
export async function handlePortal(request){const url=new URL(request.url),path=url.pathname,user=currentUser(request);let body={};try{
 if(!['GET','POST'].includes(request.method))return json({error:'Method not allowed'},405);
 if(request.method==='POST'){
  if(request.headers.get('origin')!==new URL(process.env.APP_URL||request.url).origin)return json({error:'Submit from the Qelviora website.'},403);
  if(!request.headers.get('content-type')?.includes('application/json'))return json({error:'Use JSON input.'},415);
  body=await request.json();if(!body||typeof body!=='object'||Array.isArray(body))return json({error:'Invalid request.'},400);
 }

 if(path==='/api/admin/credentials'){
  if(user?.role!=='ADMIN')return json({error:'Administrator access required.'},403);
  if(request.method==='GET')return json({email:user.email});
  limit('admin-credentials:'+user.id,5);
  const mail=clean(body.email,254).toLowerCase(),password=body.password;
  if(!email(mail)||typeof body.currentPassword!=='string'||body.currentPassword.length>128||typeof password!=='string'||password.length<12||password.length>128)return json({error:'Enter a valid email, current password and a new password of 12–128 characters.'},400);
  if(password!==body.confirmPassword)return json({error:'New passwords do not match.'},400);
  const account=one('SELECT password_hash FROM users WHERE id=?',user.id);
  if(!await passwordMatches(body.currentPassword,account.password_hash))return json({error:'Current password is incorrect.'},400);
  if(one('SELECT id FROM users WHERE email=? AND id<>?',mail,user.id))return json({error:'That email is already used by another account.'},409);
  const encoded=await passwordHash(password);
  transaction(()=>{run('UPDATE users SET email=?,password_hash=? WHERE id=?',mail,encoded,user.id);run('DELETE FROM sessions WHERE user_id=?',user.id);run('UPDATE resets SET used=1 WHERE user_id=?',user.id);audit(user,'ADMIN_CREDENTIALS_UPDATED',user.id)});
  return json({message:'Admin login updated. Sign in with your new email and password.'},200,{'Set-Cookie':'qelviora_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0'});
 }
 const methodsResult=await handlePaymentMethods(request,user,body);if(methodsResult)return methodsResult;
 const accountsResult=await handleAccounts(request,user,body);if(accountsResult)return accountsResult;
 const schemaResult=await handleFormSchema(request,user,body);if(schemaResult)return schemaResult;
 const enquiryResult=await handleEnquiries(request,user,body);if(enquiryResult)return enquiryResult;const materialResult=await handleMaterials(request,user,body);if(materialResult)return materialResult;
 const catalogResult=await handleCatalog(request,user,body);if(catalogResult)return catalogResult;
 const newsletterResult=await handleNewsletter(request,user,body);if(newsletterResult)return newsletterResult;
 const paymentResult=await handlePayments(request,user,body);if(paymentResult)return paymentResult;
 if(path==='/api/auth/me')return json({user});
 if(path==='/api/auth/register'&&request.method==='POST'){
  limit('register:'+request.headers.get('x-client-ip'),5);const name=clean(body.name,100),phone=clean(body.phone,20),mail=clean(body.email,254).toLowerCase(),password=body.password;
  if(name.length<2||!email(mail)||!/[0-9]{7}/.test(phone.replace(/\D/g,''))||typeof password!=='string'||password.length<12||password.length>128)return json({error:'Enter your name, valid mobile number and email, and a password of 12–128 characters.'},400);
  if(!body.consent)return json({error:'Confirm the account data notice.'},400);
  if(one('SELECT id FROM users WHERE email=?',mail))return json({error:'Unable to create this account. Try signing in or resetting your password.'},409);
  const id=randomUUID(),encoded=await passwordHash(password);transaction(()=>{run('INSERT INTO users(id,name,email,phone,password_hash,role,created_at) VALUES(?,?,?,?,?,?,?)',id,name,mail,phone,encoded,'STUDENT',new Date().toISOString());queueMail('qelvioratechnologies@gmail.com','New Qelviora account',`Name: ${name}\nEmail: ${mail}\nMobile: ${phone}`);audit({id},'REGISTER',id)});
  return json({user:{id,name,email:mail,phone,role:'STUDENT'}},201,session({id},request));
 }
 if(path==='/api/auth/login'&&request.method==='POST'){
  limit('login:'+request.headers.get('x-client-ip'),15);const mail=clean(body.email,254).toLowerCase(),u=one('SELECT * FROM users WHERE email=?',mail);if(typeof body.password!=='string'||body.password.length>128||!u||!await passwordMatches(body.password,u.password_hash))return json({error:'Email or password is incorrect.'},401);
  if(u.status!=='ACTIVE')return json({error:'Your account is '+(u.status==='BLOCKED'?'blocked':'deactivated')+'. Contact Qelviora for assistance.'},403);
  const old=request.headers.get('cookie')?.match(/qelviora_session=([a-f0-9]{64})/)?.[1];if(old)run('DELETE FROM sessions WHERE token_hash=?',hash(old));queueMail('qelvioratechnologies@gmail.com','Qelviora account sign-in',`Name: ${u.name}\nEmail: ${u.email}\nSigned in: ${new Date().toISOString()}`);audit(u,'LOGIN',u.id);return json({user:{id:u.id,name:u.name,email:u.email,role:u.role}},200,session(u,request));
 }
 if(path==='/api/auth/logout'&&request.method==='POST'){const token=request.headers.get('cookie')?.match(/qelviora_session=([a-f0-9]{64})/)?.[1];if(token)run('DELETE FROM sessions WHERE token_hash=?',hash(token));return json({ok:true},200,{'Set-Cookie':'qelviora_session=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0'})}
 if(path==='/api/auth/forgot'&&request.method==='POST'){
  limit('forgot:'+request.headers.get('x-client-ip'),5);if(!emailConfigured()||!process.env.APP_URL)return json({error:'Password-reset email is not configured yet. Please contact Qelviora support.'},503);
  const u=one('SELECT id,email FROM users WHERE email=?',clean(body.email,254).toLowerCase());if(u){const token=randomBytes(32).toString('hex');transaction(()=>{run('UPDATE resets SET used=1 WHERE user_id=?',u.id);run('INSERT INTO resets VALUES(?,?,?,0)',hash(token),u.id,Date.now()+1800000);queueMail(u.email,'Reset your Qelviora password',`${process.env.APP_URL}/account.html?mode=reset#token=${token}\nThis link expires in 30 minutes.`)})}return json({message:'If this email has an account, a reset link will be sent.'});
 }
 if(path==='/api/auth/reset'&&request.method==='POST'){
  limit('reset:'+request.headers.get('x-client-ip'),10);if(typeof body.token!=='string'||typeof body.password!=='string'||body.password.length<12||body.password.length>128)return json({error:'Enter a password of 12–128 characters.'},400);const r=one('SELECT * FROM resets WHERE token_hash=? AND used=0 AND expires>?',hash(body.token),Date.now());if(!r)return json({error:'This reset link is invalid or expired.'},400);const encoded=await passwordHash(body.password);transaction(()=>{if(!one('SELECT token_hash FROM resets WHERE token_hash=? AND used=0 AND expires>?',hash(body.token),Date.now()))throw Object.assign(Error('Reset link already used or expired.'),{status:400});run('UPDATE users SET password_hash=? WHERE id=?',encoded,r.user_id);run('UPDATE resets SET used=1 WHERE user_id=?',r.user_id);run('DELETE FROM sessions WHERE user_id=?',r.user_id)});return json({message:'Password updated. Sign in with your new password.'});
 }
 if(path==='/api/enquiries'&&request.method==='POST'){
  limit('enquiry:'+request.headers.get('x-client-ip'),10);const data={name:clean(body.name,100),email:clean(body.email,254),phone:clean(body.phone,20),category:clean(body.category,40),message:clean(body.message,10000)};const chat=body.chat===true&&['Training','Hackathon'].includes(data.category);if((!chat&&(!email(data.email)||!data.name))||(chat&&data.phone&&!/^[+0-9 ()-]{7,20}$/.test(data.phone))||!data.message||!body.consent)return json({error:'Enter your contact details, enquiry and consent.'},400);const recipient=data.category==='Hackathon'?'qelvioratechnologies@gmail.com':data.category==='Service'||data.category==='IT Services'?'qelvioratechnologies@gmail.com':data.category==='Internship'?'qelvioratechnologies@gmail.com':'qelvioratechnologies@gmail.com';transaction(()=>{record(randomUUID(),'enquiry',user?.id||null,data);queueMail(recipient,'Qelviora '+data.category+' enquiry',JSON.stringify(data,null,2))});return json({message:'Your enquiry is saved. The team will receive an email notification once mail delivery is configured.'},201);
 }
 if(!user)return json({error:'Please sign in to view these details.'},401);
 if(path==='/api/portal/jobs'&&request.method==='GET')return json({jobs:Object.entries(catalogLibrary('jobs')).map(([id,data])=>({id,...data}))});
 if(path==='/api/portal/content'&&request.method==='GET'){
  const type=url.searchParams.get('type'),id=url.searchParams.get('id');if(!['courses','hackathons','internships'].includes(type)||!Object.hasOwn(library[type],id||''))return json({error:'Content not found.'},404);const content={...library[type][id]};if(type==='hackathons'&&eventFee(id)>0&&!verifiedEvent(user.id,id)){return json({name:content.name,description:content.description,fee:content.fee,status:content.status,team:content.team,locked:true})}if(type==='internships'){delete content.notes;delete content.projects;delete content.resources;delete content.assessments;delete content.materials}return json({...content,configuration:setting(type+':'+id)||{}});
 }
 if(path==='/api/portal/dashboard'&&request.method==='GET')return json({user,hackathonEnrollments:records(user.id,'event-enrollment'),internships:records(user.id,'internship').map(r=>internshipView(r,user)),submissions:records(user.id,'submission'),hackathonSubmissions:records(user.id,'hackathon'),skillProgress:JSON.parse(one('SELECT data FROM learning_progress WHERE user_id=?',user.id)?.data||'{"skills":{}}')});
 if(path==='/api/portal/internship'&&request.method==='POST'){
  if(!Object.hasOwn(library.internships,body.domain)||library.internships[body.domain].status==='Coming soon'||![1,2,3,6].includes(body.months))return json({error:'Choose a domain and duration.'},400);
  const id=randomUUID(),fees={1:499,2:999,3:1299,6:1999},data={domain:body.domain,months:body.months,fee:fees[body.months],status:'AWAITING_PAYMENT',startedAt:null};transaction(()=>{record(id,'internship',user.id,data);queueMail('qelvioratechnologies@gmail.com','New internship application',`${user.name}\n${user.email}\n${JSON.stringify(data)}`)});return json({id,...data},201);
 }
 if(path==='/api/portal/payment'&&request.method==='POST'){
  const row=one("SELECT * FROM records WHERE id=? AND user_id=? AND kind='internship'",clean(body.id,100),user.id);if(!row)return json({error:'Application not found.'},404);const value=JSON.parse(row.data);if(!['AWAITING_PAYMENT','REJECTED'].includes(value.status))return json({error:'This payment is already submitted or verified.'},409);
  const reference=clean(body.reference,120),receipt=link(body.receipt);if(reference.length<5||!receipt)return json({error:'Enter a transaction reference and an HTTPS receipt link accessible to the reviewer.'},400);value.status='PENDING';value.reference=reference;value.receipt=receipt;transaction(()=>{run('UPDATE records SET data=? WHERE id=?',JSON.stringify(value),row.id);queueMail('qelvioratechnologies@gmail.com','Verify internship payment',`Learner: ${user.name}\nEmail: ${user.email}\nApplication: ${row.id}\nFee: INR ${value.fee}\nReference: ${reference}\nReceipt: ${receipt}\nVerify payment — YES: ${process.env.APP_URL||new URL(request.url).origin}/admin.html?review=${row.id}&decision=VERIFIED\nVerify payment — NO: ${process.env.APP_URL||new URL(request.url).origin}/admin.html?review=${row.id}&decision=REJECTED\nSign in as administrator and confirm the decision. No action is taken merely by opening an email link.`)});return json({message:'Payment proof saved for review. Materials unlock after approval.'});
 }
 if(path==='/api/portal/payment-options')return json({online:paymentEnabled(),keyId:paymentEnabled()?process.env.RAZORPAY_KEY_ID:null});
 if(path==='/api/portal/checkout'&&request.method==='POST'){
  const row=records(user.id,'internship').find(r=>r.id===body.id);if(!row)return json({error:'Application not found.'},404);if(!['AWAITING_PAYMENT','REJECTED'].includes(row.data.status))return json({error:'This payment is already being reviewed.'},409);
  const order=await createOrder(row.data.fee,row.id);row.data.orderId=order.id;run('UPDATE records SET data=? WHERE id=?',JSON.stringify(row.data),row.id);return json({orderId:order.id,amount:order.amount,currency:order.currency,keyId:process.env.RAZORPAY_KEY_ID});
 }
 if(path==='/api/portal/payment-confirm'&&request.method==='POST'){
  const row=records(user.id,'internship').find(r=>r.id===body.id);if(!row||!row.data.orderId)return json({error:'Payment order not found.'},404);if(row.data.status==='VERIFIED')return json({message:'Payment already approved.'});
  if(!await verifyPayment(row.data.orderId,clean(body.paymentId,100),clean(body.signature,100),row.data.fee))return json({error:'Payment has not been confirmed as captured by the provider.'},400);
  if(row.data.status!=='PENDING'){row.data.status='PENDING';row.data.reference=body.paymentId;row.data.receipt='https://dashboard.razorpay.com/app/payments/'+body.paymentId;transaction(()=>{run('UPDATE records SET data=? WHERE id=?',JSON.stringify(row.data),row.id);queueMail('qelvioratechnologies@gmail.com','Verify captured internship payment',`Student: ${user.name}\nEmail: ${user.email}\nAmount: INR ${row.data.fee}\nPayment: ${body.paymentId}\nYES — ${(process.env.APP_URL||new URL(request.url).origin)}/admin.html?review=${row.id}&decision=VERIFIED\nNO — ${(process.env.APP_URL||new URL(request.url).origin)}/admin.html?review=${row.id}&decision=REJECTED\nSign in and confirm the decision.`)})}
  return json({message:'Payment captured and saved. Qelviora will verify it before unlocking your internship.'});
 }
 if(path==='/api/portal/internship-assessment'){
  const id=body.id||url.searchParams.get('id'),month=Number(body.month||url.searchParams.get('month'));const row=records(user.id,'internship').find(r=>r.id===id);
  if(!row||row.data.status!=='VERIFIED')return json({error:'A verified internship is required.'},403);
  if(!Number.isInteger(month)||month<1||month>row.data.months)return json({error:'Choose a valid internship month.'},400);
  if(Date.now()<Date.parse(addMonths(row.data.startedAt,month)))return json({error:'This assessment opens at the end of its internship month.'},403);
  const questions=library.internships[row.data.domain]?.assessments?.[month]||monthlyBank[row.data.domain]?.[month];if(!questions)return json({error:'This monthly assessment is not yet published.'},409);
  if(request.method==='GET')return json({month,questions:questions.map(({correct,...q})=>q),passPercentage:70});
  limit('intern-assess:'+user.id,30);if(!Array.isArray(body.answers)||body.answers.length!==20||body.answers.some((a,i)=>!Number.isInteger(a)||a<0||a>=questions[i].options.length))return json({error:'Answer all 20 questions.'},400);
  const score=questions.reduce((n,q,i)=>n+(q.correct===body.answers[i]?1:0),0),attempt={month,score,total:20,passed:score>=14,date:new Date().toISOString()};row.data.assessmentAttempts||=[];row.data.assessmentAttempts.push(attempt);run('UPDATE records SET data=? WHERE id=?',JSON.stringify(row.data),row.id);return json(attempt);
 }
 if(path==='/api/portal/project'&&request.method==='POST'){
  const row=records(user.id,'internship').find(r=>r.id===body.id);if(!row)return json({error:'Internship not found.'},404);const view=internshipView(row,user);if(!view.projects.some(p=>p.month===body.month))return json({error:'This project has not unlocked yet.'},403);const projectLink=link(body.url),description=clean(body.description,5000);if(!projectLink||description.length<20)return json({error:'Add an HTTPS project link and a description of at least 20 characters.'},400);transaction(()=>{record(randomUUID(),'submission',user.id,{internship:row.id,month:body.month,url:projectLink,description,status:'SUBMITTED'});queueMail('qelvioratechnologies@gmail.com','Internship project submission',`${user.name}\n${user.email}\nMonth ${body.month}\n${projectLink}\n${description}`)});return json({message:'Project submitted and saved.'},201);
 }
 if(path==='/api/portal/hackathon'&&request.method==='POST'){
  const event=body.event,round=body.round;if(!verifiedEvent(user.id,event))return json({error:'Payment approval is required before hackathon submissions.'},403);if(event!=='hackathon-2026'||!['idea','video'].includes(round))return json({error:'Submissions for this event are coming soon.'},400);const windows={idea:['2026-11-12T00:00:00+05:30','2026-11-14T00:00:00+05:30'],video:['2026-11-18T00:00:00+05:30','2026-11-21T00:00:00+05:30']};const now=Date.now();if(now<Date.parse(windows[round][0])||now>=Date.parse(windows[round][1]))return json({error:'This submission round is not open. Check the published schedule.'},403);
  if(round==='video'&&!(setting('hackathon:round1-selected')||[]).includes(user.id))return json({error:'Video submissions are available to selected round-one participants.'},403);
  const upload=round==='idea'?one("SELECT * FROM records WHERE id=? AND user_id=? AND kind='upload'",clean(body.uploadId,100),user.id):null;const title=clean(body.title,150),description=clean(body.description,10000);let artifact=round==='idea'&&upload?new URL('/api/uploads/'+upload.id,request.url).href:link(body.url);if(round==='video'&&artifact&&!['linkedin.com','www.linkedin.com'].includes(new URL(artifact).hostname))artifact=null;if(title.length<3||description.length<20||!artifact)return json({error:round==='idea'?'Upload an idea document / PPT and enter a title and description.':'Enter a LinkedIn video post link, title and description.'},400);transaction(()=>{record(randomUUID(),'hackathon',user.id,{event,round,title,description,url:artifact});queueMail('qelvioratechnologies@gmail.com','Hackathon '+round+' submission',`${user.name}\n${user.email}\n${title}\n${artifact}\n${description}`)});return json({message:'Your submission is saved.'},201);
 }
 if(path==='/api/portal/results'&&request.method==='GET'){
  const dates={'round1':'2026-11-18T22:00:00+05:30','round2':'2026-11-28T00:00:00+05:30','winners':'2026-12-03T00:00:00+05:30'};return json(Object.fromEntries(Object.entries(dates).map(([key,date])=>[key,Date.now()>=Date.parse(date)?setting('results:'+key)||'Awaiting publication':'Publishes '+date])));
 }
 if(path==='/api/portal/certificate'&&request.method==='GET'){const item=records(user.id,'internship').map(r=>internshipView(r,user)).find(r=>r.certificate?.id===url.searchParams.get('id'));if(!item)return json({error:'Certificate not available.'},404);return new Response(renderCertificate(item.certificate),{headers:{'Content-Type':'image/svg+xml','Cache-Control':'private, no-store','Content-Security-Policy':"default-src 'none'"}})}
 if(path.startsWith('/api/admin/')){
  if(user.role!=='ADMIN')return json({error:'Administrator access required.'},403);
  if(path==='/api/admin/email-settings'&&request.method==='POST'){limit('email-settings:'+user.id,5);const result=await configureEmail(body);if(result.ok){audit(user,'CONFIGURE_EMAIL','sending-account');deliverMail().catch(()=>{});}return result;}
  if(path==='/api/admin/overview')return json({emailDelivery:{configured:emailConfigured(),pending:one("SELECT COUNT(*) AS count FROM outbox WHERE status='PENDING'").count},users:all('SELECT id,name,email,role FROM users'),payments:all("SELECT r.*,u.name,u.email FROM records r JOIN users u ON u.id=r.user_id WHERE kind IN ('internship','event-enrollment','training-enrollment') ORDER BY r.created_at DESC,r.id DESC").map(r=>({...r,data:JSON.parse(r.data)})),submissions:all("SELECT r.*,u.name,u.email FROM records r LEFT JOIN users u ON u.id=r.user_id WHERE kind IN ('submission','hackathon','enquiry') ORDER BY r.created_at DESC LIMIT 200").map(r=>({...r,data:JSON.parse(r.data)})),mail:all('SELECT id,recipient,subject,status,attempts,created_at FROM outbox ORDER BY created_at DESC LIMIT 100'),settings:all('SELECT * FROM settings').map(x=>({...x,data:JSON.parse(x.data)}))});
  if(path==='/api/admin/payment'&&request.method==='POST'){
   const row=one("SELECT * FROM records WHERE id=? AND kind IN ('internship','event-enrollment','training-enrollment')",clean(body.id,100));if(!row)return json({error:'Application not found.'},404);const v=JSON.parse(row.data);if(v.status!=='PENDING')return json({error:'Only pending payments can be reviewed.'},409);if(!['VERIFIED','REJECTED'].includes(body.status))return json({error:'Choose approve or reject.'},400);v.status=body.status;if(v.status==='VERIFIED'&&row.kind==='internship')v.startedAt=new Date().toISOString();v.feedback=clean(body.feedback,1000);transaction(()=>{run('UPDATE records SET data=? WHERE id=?',JSON.stringify(v),row.id);audit(user,'PAYMENT_'+v.status,row.id);queueMail(one('SELECT email FROM users WHERE id=?',row.user_id).email,'Qelviora payment review',`Payment ${v.status.toLowerCase()}. ${v.feedback}\nSign in to view your approved workspace.`)});return json({ok:true});
  }
  if(path==='/api/admin/settings'&&request.method==='POST'){
   const key=clean(body.key,100);if(!/^(courses:|hackathons:|internships:|results:|hackathon:round1-selected|payment-instructions)/.test(key))return json({error:'Unsupported setting.'},400);if(JSON.stringify(body.value).length>30000)return json({error:'Setting too large.'},400);run('INSERT INTO settings VALUES(?,?) ON CONFLICT(key) DO UPDATE SET data=excluded.data',key,JSON.stringify(body.value));audit(user,'UPDATE_SETTING',key);return json({ok:true});
  }
 }
 if(path==='/api/portal/payment-instructions')return json({instructions:setting('payment-instructions')||'Use the contact form for verified payment instructions. Do not pay until the team confirms the destination and terms.'});
 return json({error:'Not found.'},404);
 }catch(error){if(error.status)return json({error:error.message},error.status);console.error('Portal request failed:',error.message);return json({error:'We could not save your request. Please try again.'},500)}finally{deliverMail().catch(()=>console.error('Email queue unavailable.'))}}

export function refreshInternships(){
 for(const row of all("SELECT * FROM records WHERE kind='internship'")){
  const data=JSON.parse(row.data);if(data.status!=='VERIFIED')continue;
  const user=one('SELECT id,name,email FROM users WHERE id=?',row.user_id);
  if(user)internshipView({...row,data},user);
 }
}
