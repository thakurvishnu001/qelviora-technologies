import {readFileSync} from 'node:fs';
import { loadEnvFile } from 'node:process';
try{loadEnvFile(new URL('./.env',import.meta.url))}catch(error){if(error.code!=='ENOENT')throw error}

try{const saved=JSON.parse(readFileSync(new URL('./.data/email-config.json',import.meta.url),'utf8'));if(!process.env.EMAIL_SERVER)process.env.EMAIL_SERVER=saved.EMAIL_SERVER;if(!process.env.EMAIL_FROM)process.env.EMAIL_FROM=saved.EMAIL_FROM}catch(error){if(error.code!=='ENOENT')console.error('Email settings could not be loaded. Configure delivery in Administration.')}
