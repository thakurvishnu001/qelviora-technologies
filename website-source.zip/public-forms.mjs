import {saveFile,loadFile} from './file-store.mjs';
import {enquirySchema} from './form-schema.mjs';
import {randomUUID} from 'node:crypto';
import {mkdir,writeFile} from 'node:fs/promises';
import {resolve,join} from 'node:path';
import {fileURLToPath} from 'node:url';
import {one,run,record,transaction} from './database.mjs';
import {queueMail} from './mail.mjs';
export async function handlePublicForm(request){
 const json=(data,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store'}});
 if(request.method!=='POST')return json({error:'Method not allowed.'},405);
 if(request.headers.get('origin')!==new URL(process.env.APP_URL||request.url).origin)return json({error:'Submit from the Qelviora website.'},403);
 const key='public-form:'+request.headers.get('x-client-ip'),now=Date.now();run('DELETE FROM limits WHERE expires<?',now);if((one('SELECT count FROM limits WHERE key=?',key)?.count||0)>=10)return json({error:'Too many submissions. Please try again in 15 minutes.'},429);
 run('INSERT INTO limits VALUES(?,1,?) ON CONFLICT(key) DO UPDATE SET count=count+1',key,now+900000);
 let form;try{form=await request.formData()}catch{return json({error:'Check the form and try again.'},400)}
 if(form.get('_honey'))return json({message:'Submission received.'});
 const values={},files=[];for(const [key,value]of form){if(typeof value==='string'&&!key.startsWith('_')&&key!=='formId'){if(value.length>10000)return json({error:'A field is too long.'},400);values[key]=value.trim()}else if(typeof value!=='string'&&value.size)files.push(value)}
 const managed=['enquiry-form','popup-enquiry-form'].includes(form.get('formId'));if(managed){for(const field of enquirySchema().fields.filter(field=>field.enabled)){if(field.required&&!values[field.name])return json({error:'Complete '+field.label+' before submitting.'},400);if(field.type==='select'&&field.options.length&&values[field.name]&&!field.options.includes(values[field.name]))return json({error:'Choose a valid '+field.label+'.'},400);}}
 const name=values.name||values.full_name||values.fullName,email=values.email;
 if((!managed&&(!name||!email||!['consent','candidate_consent'].some(k=>values[k])))||(name&&name.length>120)||(email&&!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)))return json({error:'Enter your name, email and consent.'},400);
 if(JSON.stringify(values).length>30000||files.length>1)return json({error:'Use one attachment and shorter answers.'},400);
 if(form.get('formId')==='communication-registration-form'){if(!values.transaction_reference||files.length!==1)return json({error:'Enter your transaction ID and upload a payment receipt.'},400);values.paymentFee=999;values.paymentStatus='PENDING';}
 const uploads=[],folder=resolve(process.env.UPLOAD_DIRECTORY||fileURLToPath(new URL('./.data/uploads',import.meta.url)));
 for(const file of files){if(file.size>5*1024*1024)return json({error:'Attachment must be under 5 MB.'},400);const bytes=Buffer.from(await file.arrayBuffer()),ext=file.name.split('.').at(-1).toLowerCase();const valid=ext==='pdf'?bytes.subarray(0,5).toString()==='%PDF-':ext==='doc'?bytes.subarray(0,8).equals(Buffer.from('d0cf11e0a1b11ae1','hex')):ext==='docx'?bytes.subarray(0,4).equals(Buffer.from('504b0304','hex'))&&bytes.includes(Buffer.from('word/document.xml')):ext==='png'?bytes.subarray(0,8).equals(Buffer.from('89504e470d0a1a0a','hex')):['jpg','jpeg'].includes(ext)?bytes.subarray(0,3).equals(Buffer.from('ffd8ff','hex')):false;if(!valid)return json({error:'Upload a valid PDF, DOC, DOCX, PNG or JPG attachment.'},400);const id=randomUUID();await saveFile(id,bytes);uploads.push({id,filename:file.name.replace(/[^a-zA-Z0-9 ._()-]/g,'_').slice(-120),size:bytes.length})}
 const formId=String(form.get('formId')||''),category=formId==='career-application-form'?'Career':formId==='communication-registration-form'?'Training':values.category||values.enquiry_type||'General';
 const recipient=category==='Hackathon'?'qelvioratechnologies@gmail.com':category==='Service'||category==='IT Services'?'qelvioratechnologies@gmail.com':category==='Internship'?'qelvioratechnologies@gmail.com':'qelvioratechnologies@gmail.com';
 const id=randomUUID(),origin=process.env.APP_URL||new URL(request.url).origin;
 transaction(()=>{for(const file of uploads)record(file.id,'upload',null,{...file,purpose:'public-form',submissionId:id});record(id,'enquiry',null,{...values,name:name||'Anonymous',email:email||'',category,attachments:uploads.map(file=>({filename:file.filename,url:origin+'/api/uploads/'+file.id}))});queueMail(recipient,'Qelviora '+category+' submission',JSON.stringify(values,null,2)+'\nPrivate attachments (admin login required):\n'+uploads.map(file=>origin+'/api/uploads/'+file.id).join('\n'))});
 return json({message:'Your submission has been saved. The Qelviora team can review it; email notification is queued.',id},201);
}
