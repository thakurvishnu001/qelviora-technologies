import {createHmac,timingSafeEqual} from 'node:crypto';
const configured=()=>!!process.env.RAZORPAY_KEY_ID&&!!process.env.RAZORPAY_KEY_SECRET;
export function paymentEnabled(){return configured()}
async function razor(path,body){
 if(!configured())throw Object.assign(Error('Online checkout is coming soon. Contact Qelviora for confirmed payment instructions.'),{status:503});
 const response=await fetch('https://api.razorpay.com/v1/'+path,{method:body?'POST':'GET',headers:{Authorization:'Basic '+Buffer.from(process.env.RAZORPAY_KEY_ID+':'+process.env.RAZORPAY_KEY_SECRET).toString('base64'),'Content-Type':'application/json'},...(body?{body:JSON.stringify(body)}:{}),signal:AbortSignal.timeout(15000)});
 const data=await response.json();if(!response.ok)throw Object.assign(Error('Payment provider could not process this request. Please try again.'),{status:502});return data;
}
export async function createOrder(fee,id){return razor('orders',{amount:Math.round(fee*100),currency:'INR',receipt:id.slice(0,40),payment_capture:1})}
export async function verifyPayment(orderId,paymentId,signature,fee){
 if(!configured())throw Object.assign(Error('Payment service is not configured.'),{status:503});
 if(!/^pay_[A-Za-z0-9]+$/.test(paymentId)||!/^[a-f0-9]{64}$/.test(signature))return false;
 const expected=createHmac('sha256',process.env.RAZORPAY_KEY_SECRET).update(orderId+'|'+paymentId).digest('hex');
 if(!timingSafeEqual(Buffer.from(expected),Buffer.from(signature)))return false;
 const payment=await razor('payments/'+paymentId);
 return payment.order_id===orderId&&payment.amount===Math.round(fee*100)&&payment.currency==='INR'&&payment.status==='captured';
}
