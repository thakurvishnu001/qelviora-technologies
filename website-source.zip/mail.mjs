import nodemailer from './vendor/nodemailer/dist/esm/nodemailer.js';
import { randomUUID } from 'node:crypto';
import { all,run } from './database.mjs';
export function queueMail(to,subject,text){run('INSERT INTO outbox(id,recipient,subject,body,created_at) VALUES(?,?,?,?,?)',randomUUID(),to,subject,text,new Date().toISOString())}
let running=null;
export function emailConfigured(){return !!process.env.EMAIL_FROM&&!!(process.env.BREVO_API_KEY||process.env.EMAIL_SERVER)}
export function deliverMail(){
 if(running)return running;
 if(!emailConfigured())return Promise.resolve();
 running=flushMail().finally(()=>{running=null});return running;
}
async function flushMail(){
 try{
  const transport=process.env.BREVO_API_KEY?null:nodemailer.createTransport(process.env.EMAIL_SERVER);
  for(const message of all("SELECT * FROM outbox WHERE status='PENDING' AND attempts<10 ORDER BY created_at LIMIT 20")){
   try{if(process.env.BREVO_API_KEY){const response=await fetch('https://api.brevo.com/v3/smtp/email',{method:'POST',headers:{'api-key':process.env.BREVO_API_KEY,'Content-Type':'application/json'},body:JSON.stringify({sender:{name:'Qelviora Technologies',email:process.env.EMAIL_FROM},to:[{email:message.recipient}],subject:message.subject,textContent:message.body,...(/Verify.*payment/i.test(message.subject)?{htmlContent:paymentHtml(message.body)}:{})}),signal:AbortSignal.timeout(20000)});if(!response.ok)throw Error('Email provider rejected delivery.');}else await transport.sendMail({from:process.env.EMAIL_FROM,to:message.recipient,subject:message.subject,text:message.body,html:/Verify.*payment/i.test(message.subject)?paymentHtml(message.body):undefined});run("UPDATE outbox SET status='SENT',attempts=attempts+1 WHERE id=?",message.id)}
   catch{run('UPDATE outbox SET attempts=attempts+1 WHERE id=?',message.id)}
  }
 }finally{}
}
export function startMail(){setInterval(()=>deliverMail().catch(()=>console.error('Email queue unavailable.')),60000).unref();deliverMail().catch(()=>console.error('Email queue unavailable.'))}


function paymentHtml(text){const esc=value=>value.replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));const links=text.match(/https?:\/\/[^\s]+admin\.html\?review=[^\s]+/g)||[];return '<h2>Verify internship payment</h2><pre>'+esc(text)+'</pre>'+links.map((url,i)=>'<a style="display:inline-block;padding:12px 24px;margin:8px;background:'+(i?'#a62c2c':'#225d39')+';color:white;border-radius:8px" href="'+esc(i?url.replace(/&decision=[^&]+/,''):url)+'">'+(i?'Skip / review later':'Verify Payment')+'</a>').join('')+'<p>Sign in as an administrator and confirm your decision.</p>';}
