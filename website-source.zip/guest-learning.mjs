import {randomBytes,createHash} from 'node:crypto';
import {one,run,db,transaction} from './database.mjs';
const hash=value=>createHash('sha256').update(value).digest('hex');
db.exec('CREATE TABLE IF NOT EXISTS guest_learning(id TEXT PRIMARY KEY,data TEXT NOT NULL,expires INTEGER NOT NULL)');
export function learningIdentity(request,user){
 const token=request.headers.get('cookie')?.match(/(?:^|;\s*)qelviora_guest=([a-f0-9]{64})(?:;|$)/)?.[1];
 let id=token?hash(token):null;
 const row=id?one('SELECT * FROM guest_learning WHERE id=? AND expires>?',id,Date.now()):null;
 if(user){
  if(row)transaction(()=>{
   const source=JSON.parse(row.data),saved=one('SELECT data FROM learning_progress WHERE user_id=?',user.id),target=saved?JSON.parse(saved.data):{skills:{},certificates:{}};
   for(const [slug,progress] of Object.entries(source.skills||{})){
    const existing=target.skills[slug];
    if(!existing)target.skills[slug]=progress;
    else{existing.completed=[...new Set([...existing.completed,...progress.completed])].sort((a,b)=>a-b);existing.notes={...progress.notes,...existing.notes};existing.attempts=[...existing.attempts,...progress.attempts].sort((a,b)=>a.date.localeCompare(b.date)).slice(-100);existing.certificate||=progress.certificate;}
   }
   target.certificates={...source.certificates,...target.certificates};run('INSERT INTO learning_progress VALUES(?,?) ON CONFLICT(user_id) DO UPDATE SET data=excluded.data',user.id,JSON.stringify(target));run('DELETE FROM guest_learning WHERE id=?',id);
  });
  return {id:user.id,guest:false,cookie:null};
 }
 if(row)return {id:'guest:'+id,guest:true,cookie:null};
 const fresh=randomBytes(32).toString('hex');id=hash(fresh);run('INSERT INTO guest_learning VALUES(?,?,?)',id,'{"skills":{},"certificates":{}}',Date.now()+30*86400000);
 return {id:'guest:'+id,guest:true,cookie:`qelviora_guest=${fresh}; HttpOnly; SameSite=Lax; Path=/; Max-Age=2592000${new URL(process.env.APP_URL||request.url).protocol==='https:'?'; Secure':''}`};
}
export const learningStore={
 async get(key){const guest=key.startsWith('guest:');const row=one(guest?'SELECT data FROM guest_learning WHERE id=?':'SELECT data FROM learning_progress WHERE user_id=?',guest?key.slice(6):key);return row?JSON.parse(row.data):null},
 async put(key,data){if(key.startsWith('guest:'))run('UPDATE guest_learning SET data=? WHERE id=?',JSON.stringify(data),key.slice(6));else run('INSERT INTO learning_progress VALUES(?,?) ON CONFLICT(user_id) DO UPDATE SET data=excluded.data',key,JSON.stringify(data))}
};
