import nodemailer from './vendor/nodemailer/dist/esm/nodemailer.js';
import {mkdir,writeFile,rename} from 'node:fs/promises';
import {fileURLToPath} from 'node:url';
import {run} from './database.mjs';
export async function configureEmail(body){
 const user=typeof body.email==='string'?body.email.trim():'',password=typeof body.appPassword==='string'?body.appPassword.replace(/\s/g,''):'';
 if(!/^[a-zA-Z0-9._%+-]+@gmail\.com$/.test(user)||!/^[a-zA-Z0-9]{16}$/.test(password))return Response.json({error:'Enter a Gmail sender and its 16-character Google App Password.'},{status:400});
 const smtp='smtps://'+encodeURIComponent(user)+':'+encodeURIComponent(password)+'@smtp.gmail.com:465';
 const transport=nodemailer.createTransport({host:'smtp.gmail.com',port:465,secure:true,auth:{user,pass:password},connectionTimeout:15000,greetingTimeout:15000,socketTimeout:20000});
 try{await transport.verify()}catch{return Response.json({error:'The sending account could not connect. Check the Google App Password, 2-Step Verification and server network access.'},{status:400})}finally{transport.close()}
 const folder=new URL('./.data/',import.meta.url);await mkdir(folder,{recursive:true});const target=fileURLToPath(new URL('email-config.json',folder)),temporary=target+'.tmp';
 await writeFile(temporary,JSON.stringify({EMAIL_SERVER:smtp,EMAIL_FROM:user}),{mode:0o600});await rename(temporary,target);process.env.EMAIL_SERVER=smtp;process.env.EMAIL_FROM=user;run("UPDATE outbox SET attempts=0 WHERE status='PENDING'");
 return Response.json({message:'Sending account connected. Saved notifications will be delivered from the queue.'});
}
