@echo off
cd /d "%~dp0"
node --preserve-symlinks --preserve-symlinks-main admin-account-setup.mjs
pause
